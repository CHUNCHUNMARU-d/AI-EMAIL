import { useState, useEffect, useRef } from "react";

// ─── API CONFIG ───────────────────────────────────────────────────────────────
const ANTHROPIC_KEY  = import.meta.env.VITE_ANTHROPIC_KEY  || "";
const EASYBILL_KEY   = import.meta.env.VITE_EASYBILL_KEY   || "";
const OUTLOOK_TOKEN  = import.meta.env.VITE_OUTLOOK_TOKEN  || "";

// ─── DRAGON COMPUTERS LIVE CATALOG (scraped from dragoncomputers.eu) ──────────
// These are the real Firebreather builds with parsed components
const DRAGON_CATALOG = [
  { id:"DC001", name:"Firebreather Lava A5556",      url:"https://www.dragoncomputers.eu/Firebreather-Lava-A5556-AMD-Ryzen-5-5500-Radeon-RX-7600-8GB-GAMING-PC",      price:839.99,  originalPrice:1239.99, cpu:"AMD Ryzen 5 5500",      gpu:"AMD Radeon RX 7600 8GB",        ram:"16GB DDR4", storage:"1TB NVMe", category:"Gaming tot €1500" },
  { id:"DC002", name:"Firebreather Lava A5556 RTX",  url:"https://www.dragoncomputers.eu/Firebreather-Lava-A5556-AMD-Ryzen-5-5500-RTX-5060-8GB-GAMING-PC",           price:899.99,  originalPrice:1299.99, cpu:"AMD Ryzen 5 5500",      gpu:"NVIDIA RTX 5060 8GB",           ram:"16GB DDR4", storage:"1TB NVMe", category:"Gaming tot €1500" },
  { id:"DC003", name:"Firebreather White A8456",     url:"https://www.dragoncomputers.eu/Firebreather-White-A8456-AMD-8400DF-RTX5060",                                price:1099.99, originalPrice:1299.99, cpu:"AMD Ryzen 5 8400F",     gpu:"NVIDIA RTX 5060 8GB",           ram:"16GB DDR5", storage:"1TB NVMe", category:"Gaming tot €1500" },
  { id:"DC004", name:"Firebreather Mountain A8756",  url:"https://www.dragoncomputers.eu/Firebreather-Mountain-A8756-8700F-RTX5060",                                  price:1069.99, originalPrice:1439.99, cpu:"AMD Ryzen 7 8700F",     gpu:"NVIDIA RTX 5060 8GB",           ram:"16GB DDR5", storage:"1TB NVMe", category:"Gaming tot €1500" },
  { id:"DC005", name:"Firebreather THE CUBE A7546",  url:"https://www.dragoncomputers.eu/Firebreather-CUBE-A7546-7500F-RTX4060",                                      price:1079.99, originalPrice:1339.99, cpu:"AMD Ryzen 5 7500F",     gpu:"NVIDIA RTX 5060 8GB",           ram:"16GB DDR5", storage:"1TB NVMe", category:"Gaming tot €1500" },
  { id:"DC006", name:"Firebreather Lava I3446",      url:"https://www.dragoncomputers.eu/Firebreather-Lava-I3446-13400F-RTX4060",                                     price:1299.99, originalPrice:1299.99, cpu:"Intel Core i5-13400F",  gpu:"NVIDIA RTX 5060 8GB",           ram:"16GB DDR4", storage:"1TB NVMe", category:"Gaming tot €1500" },
  { id:"DC007", name:"Firebreather White A8458I",    url:"https://www.dragoncomputers.eu/Firebreather-White-A8458I-AMD-8400DF-ARC-B580-12GB",                         price:999.99,  originalPrice:1399.99, cpu:"AMD Ryzen 5 8400F",     gpu:"Intel Arc B580 12GB",           ram:"16GB DDR5", storage:"1TB NVMe", category:"Gaming tot €1500" },
  { id:"DC008", name:"Firebreather Lava I4646",      url:"https://www.dragoncomputers.eu/Firebreather-Lava-I4646-14600KF-RTX4060",                                    price:1169.99, originalPrice:1489.99, cpu:"Intel Core i5-14600KF", gpu:"NVIDIA RTX 5060 8GB",           ram:"16GB DDR5", storage:"1TB NVMe", category:"Gaming tot €1500" },
  { id:"DC009", name:"Firebreather Mountain A7556T", url:"https://www.dragoncomputers.eu/Firebreather-Mountain-A7556T-7500F-RX9060XT-16GB",                           price:1199.99, originalPrice:1499.99, cpu:"AMD Ryzen 5 7500F",     gpu:"AMD Radeon RX 9060 XT 16GB",    ram:"16GB DDR5", storage:"1TB NVMe", category:"Gaming tot €1500" },
  { id:"DC010", name:"Firebreather Eden A8757",      url:"https://www.dragoncomputers.eu/Firebreather-Eden-A8757-8700F-RTX5070",                                      price:1399.99, originalPrice:1599.99, cpu:"AMD Ryzen 7 8700F",     gpu:"NVIDIA RTX 5070 12GB",          ram:"16GB DDR5", storage:"1TB NVMe", category:"Gaming v.a. €1500" },
  { id:"DC011", name:"Firebreather Lava A754616",    url:"https://www.dragoncomputers.eu/Firebreather-Lava-A754608-7500F-RX9060XT-16GB",                              price:1439.99, originalPrice:1439.99, cpu:"AMD Ryzen 5 7500F",     gpu:"AMD Radeon RX 9060 XT 16GB",    ram:"16GB DDR5", storage:"1TB NVMe", category:"Gaming v.a. €1500" },
  { id:"DC012", name:"Firebreather Lava I3456T",     url:"https://www.dragoncomputers.eu/Firebreather-Lava-I3456T-13400F-RX9060XT-16GB",                             price:1699.99, originalPrice:1699.99, cpu:"Intel Core i5-13400F",  gpu:"AMD Radeon RX 9060 XT 16GB",    ram:"16GB DDR5", storage:"1TB NVMe", category:"Gaming v.a. €1500" },
  { id:"DC013", name:"Firebreather Curve A8796",     url:"https://www.dragoncomputers.eu/Firebreather-Curve-A8796-8700F-RX9060XT-16GB",                              price:1599.99, originalPrice:1799.99, cpu:"AMD Ryzen 7 8700F",     gpu:"AMD Radeon RX 9060 XT 16GB",    ram:"32GB DDR5", storage:"1TB NVMe", category:"Gaming v.a. €1500" },
  { id:"DC014", name:"Firebreather Eden A9657T",     url:"https://www.dragoncomputers.eu/Firebreather-Eden-A9657T-9600X-RTX5070Ti",                                   price:1729.99, originalPrice:2149.99, cpu:"AMD Ryzen 5 9600X",     gpu:"NVIDIA RTX 5070 Ti 16GB",       ram:"16GB DDR5", storage:"1TB NVMe", category:"Gaming v.a. €1500" },
  { id:"DC015", name:"Firebreather Lava A7846",      url:"https://www.dragoncomputers.eu/Firebreather-Lava-A7846-7800X3D-RTX4060",                                    price:1849.99, originalPrice:1849.99, cpu:"AMD Ryzen 7 7800X3D",   gpu:"NVIDIA RTX 5060 8GB",           ram:"16GB DDR5", storage:"1TB SSD",  category:"Gaming v.a. €1500" },
  { id:"DC016", name:"Firebreather Lava A7856T",     url:"https://www.dragoncomputers.eu/Firebreather-Lava-A7556T-7800X3D-RX9060XT-16GB",                            price:1849.99, originalPrice:1849.99, cpu:"AMD Ryzen 7 7800X3D",   gpu:"AMD Radeon RX 9060 XT 16GB",    ram:"32GB DDR5", storage:"1TB NVMe", category:"Gaming v.a. €1500" },
  { id:"DC017", name:"Firebreather Mountain A8796",  url:"https://www.dragoncomputers.eu/Firebreather-Mountain-A8796-8700F-RX-9060XT-16GB",                          price:1849.99, originalPrice:1849.99, cpu:"AMD Ryzen 7 8700F",     gpu:"AMD Radeon RX 9060 XT 16GB",    ram:"16GB DDR5", storage:"1TB NVMe", category:"Gaming v.a. €1500" },
  { id:"DC018", name:"Firebreather Eden A7557X3D",   url:"https://www.dragoncomputers.eu/Firebreather-Eden-A7557X3D-7500X3D-RTX5070Ti-16GB",                         price:1699.99, originalPrice:2209.99, cpu:"AMD Ryzen 5 7500X3D",   gpu:"NVIDIA RTX 5070 Ti 16GB",       ram:"16GB DDR5", storage:"1TB NVMe", category:"Gaming v.a. €1500" },
  { id:"DC019", name:"Firebreather Lava I2957",      url:"https://www.dragoncomputers.eu/Firebreather-Lava-I2957-12900KF-RTX5070",                                    price:1559.99, originalPrice:2139.99, cpu:"Intel Core i9-12900KF", gpu:"NVIDIA RTX 5070 12GB",          ram:"16GB DDR4", storage:"1TB NVMe", category:"Gaming v.a. €1500" },
  { id:"DC020", name:"Firebreather Diamond A9896X3D",url:"https://www.dragoncomputers.eu/Firebreather-Diamond-A9896X3D-RX9060XT-16GB-High-End-Gaming-PC",            price:1799.99, originalPrice:2299.99, cpu:"AMD Ryzen 7 9800X3D",   gpu:"AMD Radeon RX 9060 XT 16GB",    ram:"32GB DDR5", storage:"1TB NVMe", category:"Gaming v.a. €1500" },
  { id:"DC021", name:"Firebreather Lava A7857",      url:"https://www.dragoncomputers.eu/Firebreather-Lava-A7857-7800X3D-RTX5070",                                    price:1979.99, originalPrice:1979.99, cpu:"AMD Ryzen 7 7800X3D",   gpu:"NVIDIA RTX 5070 12GB",          ram:"16GB DDR5", storage:"1TB SSD",  category:"Gaming v.a. €1500" },
  { id:"DC022", name:"Firebreather Diamond A7597X3D",url:"https://www.dragoncomputers.eu/Firebreather-Diamond-A7597X3D-Gaming-PC",                                    price:1999.99, originalPrice:2499.99, cpu:"AMD Ryzen 5 7500X3D",   gpu:"AMD Radeon RX 9070 XT 16GB",    ram:"32GB DDR5", storage:"1TB NVMe", category:"Gaming v.a. €1500" },
  { id:"DC023", name:"Firebreather Eden A7857T",     url:"https://www.dragoncomputers.eu/Firebreather-Eden-A7848X3D-7800X3D-RTX5070Ti",                               price:1999.99, originalPrice:2529.99, cpu:"AMD Ryzen 7 7800X3D",   gpu:"NVIDIA RTX 5070 Ti 16GB",       ram:"16GB DDR5", storage:"1TB SSD",  category:"Gaming v.a. €1500" },
  { id:"DC024", name:"Firebreather Lava I2957Ti",    url:"https://www.dragoncomputers.eu/Firebreather-Lava-I2957Ti-12900KF-RTX5070-Ti-16GB",                         price:1899.99, originalPrice:2399.99, cpu:"Intel Core i9-12900KF", gpu:"NVIDIA RTX 5070 Ti 16GB",       ram:"16GB DDR4", storage:"1TB NVMe", category:"Gaming v.a. €1500" },
  { id:"DC025", name:"Firebreather Curve A7857",     url:"https://www.dragoncomputers.eu/Firebreather-Curve-A7857-7800X3D-RTX5070",                                   price:2299.99, originalPrice:2299.99, cpu:"AMD Ryzen 7 7800X3D",   gpu:"NVIDIA RTX 5070 12GB",          ram:"32GB DDR5", storage:"1TB NVMe", category:"Monster PCs" },
  { id:"DC026", name:"Firebreather All WHITE A7857X3D",url:"https://www.dragoncomputers.eu/Firebreather-ALL-WHITE-A7857X3D-7800X3D-RTX5070",                         price:1799.99, originalPrice:2399.99, cpu:"AMD Ryzen 7 7800X3D",   gpu:"NVIDIA RTX 5070 12GB",          ram:"16GB DDR5", storage:"1TB NVMe", category:"Monster PCs" },
  { id:"DC027", name:"Firebreather Asteri A7857T",   url:"https://www.dragoncomputers.eu/Firebreather-Asteri-A7857T-7800X3D-RTX5070Ti",                               price:2199.99, originalPrice:2699.99, cpu:"AMD Ryzen 7 7800X3D",   gpu:"NVIDIA RTX 5070 Ti 16GB",       ram:"32GB DDR5", storage:"1TB SSD",  category:"Monster PCs" },
  { id:"DC028", name:"Firebreather Wood A7857T",     url:"https://www.dragoncomputers.eu/Firebreather-Wood-A7857T-7800X3D-RTX5070Ti-16GB",                           price:2299.99, originalPrice:2999.99, cpu:"AMD Ryzen 7 7800X3D",   gpu:"NVIDIA RTX 5070 Ti 16GB",       ram:"32GB DDR5", storage:"1TB NVMe", category:"Monster PCs" },
  { id:"DC029", name:"Firebreather All White A7857X3D Extreme",url:"https://www.dragoncomputers.eu/Firebreather-All-White-A7857X3D-Extreme-Gaming-PC",               price:2329.99, originalPrice:2699.99, cpu:"AMD Ryzen 7 7800X3D",   gpu:"NVIDIA RTX 5070 Ti 16GB",       ram:"32GB DDR5", storage:"1TB NVMe", category:"Monster PCs" },
  { id:"DC030", name:"Firebreather Eruption I47KF57T",url:"https://www.dragoncomputers.eu/Firebreather-Eruption-I47KF57T-14700KF-RTX5070Ti",                         price:2239.99, originalPrice:2539.99, cpu:"Intel Core i7-14700KF", gpu:"NVIDIA RTX 5070 Ti 16GB",       ram:"32GB DDR5", storage:"1TB SSD",  category:"Monster PCs" },
  { id:"DC031", name:"Firebreather Asteri A7858X3D", url:"https://www.dragoncomputers.eu/Firebreather-Asteri-A7858X3D-AMD-Ryzen7-7800X3D-RTX5080-GAMING-PC",         price:2669.99, originalPrice:3399.99, cpu:"AMD Ryzen 7 7800X3D",   gpu:"NVIDIA RTX 5080 16GB",          ram:"32GB DDR5", storage:"1TB SSD",  category:"Monster PCs" },
  { id:"DC032", name:"Firebreather Deluxe A7858X3D", url:"https://www.dragoncomputers.eu/Firebreather-Deluxe-A7858X3D-AMD-7800X3D-RTX5080-16GB-EXTREEM-GAMING-PC",   price:2499.99, originalPrice:3299.99, cpu:"AMD Ryzen 7 7800X3D",   gpu:"NVIDIA RTX 5080 16GB",          ram:"32GB DDR5", storage:"1TB SSD",  category:"Monster PCs" },
  { id:"DC033", name:"Firebreather Curve A9857T",    url:"https://www.dragoncomputers.eu/Firebreather-Curve-A9857T-9800X3D-RTX5070Ti-E",                             price:2999.99, originalPrice:2999.99, cpu:"AMD Ryzen 7 9800X3D",   gpu:"NVIDIA RTX 5070 Ti 16GB",       ram:"32GB DDR5", storage:"1TB NVMe", category:"Monster PCs" },
  { id:"DC034", name:"Firebreather Wood A9858",      url:"https://www.dragoncomputers.eu/Firebreather-Wood-A9858-9800X3D-RTX5080-16GB",                               price:2999.99, originalPrice:3499.99, cpu:"AMD Ryzen 7 9800X3D",   gpu:"NVIDIA RTX 5080 16GB",          ram:"32GB DDR5", storage:"1TB NVMe", category:"Monster PCs" },
  { id:"DC035", name:"Firebreather Deluxe A98X3D58", url:"https://www.dragoncomputers.eu/Firebreather-Deluxe-A98X3D58-9800X3D-RTX5080",                              price:3279.99, originalPrice:3279.99, cpu:"AMD Ryzen 7 9800X3D",   gpu:"NVIDIA RTX 5080 16GB",          ram:"32GB DDR5", storage:"1TB SSD",  category:"Monster PCs" },
  { id:"DC036", name:"Firebreather Deluxe A9858X3D", url:"https://www.dragoncomputers.eu/Firebreather-Deluxe-A9858X3D-9800X3D-RTX5080",                              price:3249.99, originalPrice:3249.99, cpu:"AMD Ryzen 7 9800X3D",   gpu:"NVIDIA RTX 5080 16GB",          ram:"32GB DDR5", storage:"1TB SSD",  category:"Monster PCs" },
  { id:"DC037", name:"Firebreather Wood I4958",      url:"https://www.dragoncomputers.eu/Firebreather-Wood-I4958-14900KF-RTX5080-16GB",                               price:2859.99, originalPrice:3229.99, cpu:"Intel Core i9-14900KF", gpu:"NVIDIA RTX 5080 16GB",          ram:"32GB DDR5", storage:"1TB NVMe", category:"Monster PCs" },
  { id:"DC038", name:"Firebreather Asteri I4958",    url:"https://www.dragoncomputers.eu/Firebreather-Asteri-I4958-14900KF-RTX5080",                                  price:3399.99, originalPrice:3399.99, cpu:"Intel Core i9-14900KF", gpu:"NVIDIA RTX 5080 16GB",          ram:"32GB DDR5", storage:"1TB SSD",  category:"Monster PCs" },
  { id:"DC039", name:"Firebreather All WHITE A98558", url:"https://www.dragoncomputers.eu/Firebreather-All-WHITE-A98558-AMD-Ryzen-9850X3D-RTX5080-16GB-High-End-Gaming-PC", price:2999.99, originalPrice:4199.99, cpu:"AMD Ryzen 7 9850X3D", gpu:"NVIDIA RTX 5080 16GB",        ram:"32GB DDR5", storage:"1TB NVMe", category:"Monster PCs" },
  { id:"DC040", name:"Firebreather Curve A98558",    url:"https://www.dragoncomputers.eu/Firebreather-Curve-A98558-9850X3D-RTX5080-16GB",                             price:2999.99, originalPrice:3999.99, cpu:"AMD Ryzen 7 9850X3D",   gpu:"NVIDIA RTX 5080 16GB",          ram:"32GB DDR5", storage:"1TB NVMe", category:"Monster PCs" },
  { id:"DC041", name:"Firebreather Touch A9859T",    url:"https://www.dragoncomputers.eu/witte-Firebreather-Aorus-Touch-A9859T-9850X3D-RTX5090",                      price:4999.99, originalPrice:6999.99, cpu:"AMD Ryzen 7 9850X3D",   gpu:"NVIDIA RTX 5090 32GB",          ram:"32GB DDR5", storage:"1TB SSD",  category:"Monster PCs" },
  { id:"DC042", name:"Firebreather Diamond A7557X3D",url:"https://www.dragoncomputers.eu/Firebreather-Diamond-A7557X3D-7500X3D-RTX5070-12GB",                        price:2199.99, originalPrice:2199.99, cpu:"AMD Ryzen 5 7500X3D",   gpu:"NVIDIA RTX 5070 12GB",          ram:"32GB DDR5", storage:"1TB NVMe", category:"Monster PCs" },
  { id:"DC043", name:"Firebreather Lava A7897XT",    url:"https://www.dragoncomputers.eu/Firebreather-Lava-A7897XT-7800X3D-RX9070XT",                                 price:1879.99, originalPrice:2349.99, cpu:"AMD Ryzen 7 7800X3D",   gpu:"AMD Radeon RX 9070 XT 16GB",    ram:"32GB DDR5", storage:"1TB NVMe", category:"Gaming v.a. €1500" },
  { id:"DC044", name:"Firebreather Asteri A9897X3D", url:"https://www.dragoncomputers.eu/Firebreather-Asteri-A7897XT-9800X3D-RX9070XT",                               price:2099.99, originalPrice:2699.99, cpu:"AMD Ryzen 7 9800X3D",   gpu:"AMD Radeon RX 9070 XT 16GB",    ram:"32GB DDR5", storage:"1TB SSD",  category:"Monster PCs" },
];

// ─── MOCK EASYBILL PARTS INVENTORY ────────────────────────────────────────────
const MOCK_PARTS = [
  // CPUs
  { id:"P001", sku:"CPU-R5-5500",   name:"AMD Ryzen 5 5500",        category:"CPU", stock:4,  price:89.00  },
  { id:"P002", sku:"CPU-R5-7500F",  name:"AMD Ryzen 5 7500F",       category:"CPU", stock:6,  price:149.00 },
  { id:"P003", sku:"CPU-R5-7500X3D",name:"AMD Ryzen 5 7500X3D",    category:"CPU", stock:2,  price:199.00 },
  { id:"P004", sku:"CPU-R5-8400F",  name:"AMD Ryzen 5 8400F",       category:"CPU", stock:5,  price:129.00 },
  { id:"P005", sku:"CPU-R5-9600X",  name:"AMD Ryzen 5 9600X",       category:"CPU", stock:3,  price:229.00 },
  { id:"P006", sku:"CPU-R7-7800X3D",name:"AMD Ryzen 7 7800X3D",    category:"CPU", stock:3,  price:329.00 },
  { id:"P007", sku:"CPU-R7-8700F",  name:"AMD Ryzen 7 8700F",       category:"CPU", stock:4,  price:189.00 },
  { id:"P008", sku:"CPU-R7-9800X3D",name:"AMD Ryzen 7 9800X3D",    category:"CPU", stock:2,  price:449.00 },
  { id:"P009", sku:"CPU-R7-9850X3D",name:"AMD Ryzen 7 9850X3D",    category:"CPU", stock:0,  price:499.00 },
  { id:"P010", sku:"CPU-I5-12400F", name:"Intel Core i5-12400F",    category:"CPU", stock:3,  price:139.00 },
  { id:"P011", sku:"CPU-I5-13400F", name:"Intel Core i5-13400F",    category:"CPU", stock:5,  price:159.00 },
  { id:"P012", sku:"CPU-I5-14600KF",name:"Intel Core i5-14600KF",  category:"CPU", stock:2,  price:249.00 },
  { id:"P013", sku:"CPU-I7-14700KF",name:"Intel Core i7-14700KF",  category:"CPU", stock:1,  price:369.00 },
  { id:"P014", sku:"CPU-I9-12900KF",name:"Intel Core i9-12900KF",  category:"CPU", stock:2,  price:279.00 },
  { id:"P015", sku:"CPU-I9-14900KF",name:"Intel Core i9-14900KF",  category:"CPU", stock:1,  price:549.00 },
  // GPUs
  { id:"P020", sku:"GPU-RTX5060-8", name:"NVIDIA RTX 5060 8GB",     category:"GPU", stock:7,  price:329.00 },
  { id:"P021", sku:"GPU-RTX5070-12",name:"NVIDIA RTX 5070 12GB",    category:"GPU", stock:4,  price:599.00 },
  { id:"P022", sku:"GPU-RTX5070T-16",name:"NVIDIA RTX 5070 Ti 16GB",category:"GPU", stock:3,  price:799.00 },
  { id:"P023", sku:"GPU-RTX5080-16",name:"NVIDIA RTX 5080 16GB",    category:"GPU", stock:1,  price:1099.00},
  { id:"P024", sku:"GPU-RTX5090-32",name:"NVIDIA RTX 5090 32GB",    category:"GPU", stock:0,  price:1999.00},
  { id:"P025", sku:"GPU-RX9060XT-16",name:"AMD Radeon RX 9060 XT 16GB",category:"GPU",stock:5,price:449.00 },
  { id:"P026", sku:"GPU-RX9070XT-16",name:"AMD Radeon RX 9070 XT 16GB",category:"GPU",stock:2,price:599.00 },
  { id:"P027", sku:"GPU-RX7600-8",  name:"AMD Radeon RX 7600 8GB",  category:"GPU", stock:3,  price:249.00 },
  { id:"P028", sku:"GPU-ARCB580-12",name:"Intel Arc B580 12GB",     category:"GPU", stock:4,  price:279.00 },
  // RAM
  { id:"P030", sku:"RAM-16-DDR4",   name:"16GB DDR4",               category:"RAM", stock:15, price:39.00  },
  { id:"P031", sku:"RAM-32-DDR4",   name:"32GB DDR4",               category:"RAM", stock:8,  price:69.00  },
  { id:"P032", sku:"RAM-16-DDR5",   name:"16GB DDR5",               category:"RAM", stock:18, price:59.00  },
  { id:"P033", sku:"RAM-32-DDR5",   name:"32GB DDR5",               category:"RAM", stock:10, price:99.00  },
  { id:"P034", sku:"RAM-64-DDR5",   name:"64GB DDR5",               category:"RAM", stock:3,  price:179.00 },
  // Storage
  { id:"P040", sku:"SSD-512GB",     name:"512GB NVMe SSD",          category:"Storage", stock:20, price:49.00  },
  { id:"P041", sku:"SSD-1TB",       name:"1TB NVMe SSD",            category:"Storage", stock:25, price:79.00  },
  { id:"P042", sku:"SSD-2TB",       name:"2TB NVMe SSD",            category:"Storage", stock:10, price:119.00 },
];

// ─── COMPONENT MATCHING LOGIC ─────────────────────────────────────────────────

function matchPartToStock(componentStr, parts) {
  const s = componentStr.toLowerCase();
  return parts.filter(p => {
    const n = p.name.toLowerCase();
    // GPU matching
    if (s.includes("rtx 5090")) return n.includes("rtx 5090") || n.includes("5090");
    if (s.includes("rtx 5080")) return n.includes("rtx 5080") || n.includes("5080");
    if (s.includes("rtx 5070 ti")) return n.includes("5070 ti") || n.includes("5070t");
    if (s.includes("rtx 5070")) return (n.includes("rtx 5070") || n.includes("5070")) && !n.includes("ti");
    if (s.includes("rtx 5060 ti")) return n.includes("5060 ti");
    if (s.includes("rtx 5060")) return (n.includes("rtx 5060") || n.includes("5060")) && !n.includes("ti");
    if (s.includes("rx 9070 xt")) return n.includes("9070 xt");
    if (s.includes("rx 9060 xt")) return n.includes("9060 xt");
    if (s.includes("rx 7600")) return n.includes("rx 7600") || n.includes("7600 8gb");
    if (s.includes("arc b580")) return n.includes("arc b580") || n.includes("b580");
    // CPU matching
    if (s.includes("9800x3d")) return n.includes("9800x3d");
    if (s.includes("9850x3d")) return n.includes("9850x3d");
    if (s.includes("7800x3d")) return n.includes("7800x3d");
    if (s.includes("7500x3d")) return n.includes("7500x3d");
    if (s.includes("ryzen 7 9800")) return n.includes("9800x3d");
    if (s.includes("ryzen 7 9850")) return n.includes("9850x3d");
    if (s.includes("ryzen 7 7800")) return n.includes("7800x3d");
    if (s.includes("ryzen 5 9600")) return n.includes("9600x");
    if (s.includes("ryzen 5 7500")) return n.includes("7500f") || n.includes("7500x3d");
    if (s.includes("ryzen 5 8400")) return n.includes("8400f");
    if (s.includes("ryzen 5 5500")) return n.includes("5500");
    if (s.includes("ryzen 7 8700")) return n.includes("8700f");
    if (s.includes("i9-14900") || s.includes("i9 14900")) return n.includes("14900kf");
    if (s.includes("i9-12900") || s.includes("i9 12900")) return n.includes("12900kf");
    if (s.includes("i7-14700") || s.includes("i7 14700")) return n.includes("14700kf");
    if (s.includes("i5-14600") || s.includes("i5 14600")) return n.includes("14600kf");
    if (s.includes("i5-13400") || s.includes("i5 13400")) return n.includes("13400f");
    if (s.includes("i5-12400") || s.includes("i5 12400")) return n.includes("12400f");
    // RAM
    if (s.includes("32gb ddr5")) return n === "32gb ddr5";
    if (s.includes("16gb ddr5")) return n === "16gb ddr5";
    if (s.includes("32gb ddr4")) return n === "32gb ddr4";
    if (s.includes("16gb ddr4")) return n === "16gb ddr4";
    return false;
  })[0] || null;
}

function analyzeBuildability(build, parts) {
  const components = [
    { type:"CPU",     value: build.cpu },
    { type:"GPU",     value: build.gpu },
    { type:"RAM",     value: build.ram },
    { type:"Storage", value: build.storage },
  ];
  const results = components.map(c => {
    const match = matchPartToStock(c.value, parts);
    return {
      type: c.type,
      label: c.value,
      part: match,
      inStock: match ? (match.stock === null || match.stock > 0) : null,
      stock: match?.stock ?? null,
      notFound: !match,
    };
  });
  const found    = results.filter(r => !r.notFound);
  const inStock  = results.filter(r => r.inStock === true);
  const outStock = results.filter(r => r.inStock === false);
  const notFound = results.filter(r => r.notFound);
  let status, color, icon;
  if (outStock.length > 0)      { status = "BLOCKED";  color = "#ff4466"; icon = "❌"; }
  else if (notFound.length > 0) { status = "PARTIAL";  color = "#ffaa00"; icon = "⚠️"; }
  else if (inStock.length === 4){ status = "BUILDABLE"; color = "#00ff88"; icon = "✅"; }
  else                          { status = "PARTIAL";  color = "#ffaa00"; icon = "⚠️"; }
  return { components: results, status, color, icon, outStock, notFound };
}

// ─── CONSTANTS ────────────────────────────────────────────────────────────────

const CATEGORIES = {
  ORDER_STATUS:         { label:"Order Status",  color:"#00d4ff", icon:"📦", bg:"#00d4ff12" },
  BUDGET_BUILD_REQUEST: { label:"Budget Build",  color:"#00ff88", icon:"🖥️", bg:"#00ff8812" },
  STOCK_QUESTION:       { label:"Stock",         color:"#ffaa00", icon:"🔍", bg:"#ffaa0012" },
  TECHNICAL_SUPPORT:    { label:"Tech Support",  color:"#ff4466", icon:"🔧", bg:"#ff446612" },
  UPGRADE_REQUEST:      { label:"Upgrade",       color:"#ff88ff", icon:"⚡", bg:"#ff88ff12" },
  GENERAL_INQUIRY:      { label:"General",       color:"#aa88ff", icon:"💬", bg:"#aa88ff12" },
};

const INITIAL_EMAILS = [
  { id:1, from:"marco.rossi@gmail.com",  subject:"Firebreather Wood A9858 — is this in stock?", body:"Hi, I'm interested in the Firebreather Wood A9858 with the RTX 5080 and Ryzen 7 9800X3D. Can you confirm it's available and ready to ship? I saw it on your site for €2999.", date:"2026-03-06T09:14:00", status:"UNREAD", starred:false, archived:false, result:null, labels:[] },
  { id:2, from:"sarah.k@hotmail.com",    subject:"Gaming PC around €1500",                      body:"Hello! I want a gaming PC for around €1500, mainly for Cyberpunk 2077 and streaming. I saw some Firebreather models on your site. What's available and ready to go?", date:"2026-03-06T08:52:00", status:"UNREAD", starred:false, archived:false, result:null, labels:[] },
  { id:3, from:"tomas.v@outlook.com",    subject:"RTX 5080 builds available?",                  body:"Do you have any Firebreather builds with the RTX 5080 ready to ship right now? Looking to buy this week if possible.", date:"2026-03-06T08:31:00", status:"UNREAD", starred:false, archived:false, result:null, labels:[] },
  { id:4, from:"kevin.m@gmail.com",      subject:"Upgrade to RTX 5070 Ti build?",               body:"I bought the Firebreather Eden A8757 last month. How much would it cost to upgrade to an RTX 5070 Ti build? Is the Firebreather Asteri A7857T available?", date:"2026-03-05T16:20:00", status:"UNREAD", starred:false, archived:false, result:null, labels:[] },
  { id:5, from:"alex.g@gmail.com",       subject:"PC keeps crashing",                           body:"I bought a Firebreather Mountain A8756 from you 2 months ago and it keeps crashing. Screen goes black during games. Please help!", date:"2026-03-05T07:45:00", status:"UNREAD", starred:true,  archived:false, result:null, labels:[] },
];

function timeAgo(d) {
  const diff = Date.now() - new Date(d).getTime();
  const m = Math.floor(diff/60000);
  if (m<60) return `${m}m ago`;
  const h = Math.floor(m/60);
  if (h<24) return `${h}h ago`;
  return `${Math.floor(h/24)}d ago`;
}

function TW({ text, speed=4 }) {
  const [d,setD]=useState(""); const [done,setDone]=useState(false); const r=useRef(0);
  useEffect(()=>{ setD(""); setDone(false); r.current=0; if(!text) return;
    const iv=setInterval(()=>{ if(r.current<text.length){setD(text.slice(0,++r.current));}else{setDone(true);clearInterval(iv);} },speed);
    return ()=>clearInterval(iv); },[text]);
  return <span>{d}{!done&&<span style={{animation:"blink 1s infinite",display:"inline-block"}}>▋</span>}</span>;
}

function Toast({ msg, type, onDone }) {
  useEffect(()=>{ const t=setTimeout(onDone,3000); return ()=>clearTimeout(t); },[]);
  const c=type==="success"?"#00ff88":type==="error"?"#ff4466":"#00d4ff";
  return <div style={{position:"fixed",bottom:24,right:24,zIndex:9999,padding:"10px 18px",background:"#0d0d1e",border:`1px solid ${c}44`,borderLeft:`3px solid ${c}`,color:c,fontSize:11,fontFamily:"monospace",animation:"slideIn .3s ease",boxShadow:"0 8px 32px #000c"}}>{msg}</div>;
}

// ─── BUILDABILITY BADGE ───────────────────────────────────────────────────────

function BuildBadge({ status, color, icon, small }) {
  return (
    <span style={{ fontSize:small?7:9, padding:small?"1px 5px":"2px 8px", background:`${color}15`, color, border:`1px solid ${color}33`, letterSpacing:.5, whiteSpace:"nowrap" }}>
      {icon} {status}
    </span>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────

export default function App() {
  const [mainTab, setMainTab]         = useState("builds"); // builds | inbox | parts
  const [parts, setParts]             = useState(MOCK_PARTS);
  const [catalog]                     = useState(DRAGON_CATALOG);
  const [emails, setEmails]           = useState(INITIAL_EMAILS);
  const [selected, setSelected]       = useState(null);
  const [processing, setProcessing]   = useState(false);
  const [replyOpen, setReplyOpen]     = useState(false);
  const [replyBody, setReplyBody]     = useState("");
  const [toast, setToast]             = useState(null);
  const [search, setSearch]           = useState("");
  const [buildFilter, setBuildFilter] = useState("all");
  const [catFilter, setCatFilter]     = useState("all");
  const [syncLoading, setSyncLoading] = useState(false);
  const [lastSync, setLastSync]       = useState(null);
  const [detailTab, setDetailTab]     = useState("reply");
  const [showSetup, setShowSetup]     = useState(false);
  const [easybillKey, setEasybillKey] = useState("");
  const [ebConnected, setEbConnected] = useState(false);

  const showToast = (msg,type="info") => setToast({msg,type});

  // ── Compute buildability for all builds ──────────────────────────────────

  const buildsWithStatus = catalog.map(b => ({
    ...b,
    buildability: analyzeBuildability(b, parts)
  }));

  const buildable  = buildsWithStatus.filter(b => b.buildability.status === "BUILDABLE");
  const partial    = buildsWithStatus.filter(b => b.buildability.status === "PARTIAL");
  const blocked    = buildsWithStatus.filter(b => b.buildability.status === "BLOCKED");

  // ── Sync Easybill parts ───────────────────────────────────────────────────

  async function syncEasybill() {
    setSyncLoading(true);
    const key = easybillKey.trim() || EASYBILL_KEY;
    try {
      if (key) {
        const res = await fetch("/api/easybill/rest/v1/positions?limit=100", {
          headers: { "Authorization":`Bearer ${key}` }
        });
        if (res.ok) {
          const data = await res.json();
          if (data.items?.length > 0) {
            setParts(data.items.map(p=>({ id:String(p.id), sku:p.number||"", name:p.title, category:"Part", stock:p.stock_count??null, price:parseFloat(p.price_netto)||0 })));
            showToast(`✓ ${data.items.length} parts synced from Easybill`,"success");
          }
        } else throw new Error("API error");
      } else {
        setParts(prev => prev.map(p => ({ ...p, stock: p.stock !== null ? Math.max(0, p.stock + Math.floor(Math.random()*3)-1) : null })));
        showToast("Demo sync complete — stock levels refreshed","info");
      }
      setLastSync(new Date());
    } catch(e) {
      showToast("Sync failed — using cached data","error");
    } finally { setSyncLoading(false); }
  }

  // ── Build context string for Claude ──────────────────────────────────────

  function buildAIContext() {
    const buildableList = buildable.slice(0,10).map(b=>`- ${b.name} | €${b.price} | ${b.cpu} + ${b.gpu} + ${b.ram}`).join("\n");
    const blockedGPUs   = parts.filter(p=>p.category==="GPU"&&p.stock===0).map(p=>p.name).join(", ");
    const blockedCPUs   = parts.filter(p=>p.category==="CPU"&&p.stock===0).map(p=>p.name).join(", ");
    return `
=== DRAGON COMPUTERS — LIVE CATALOG & STOCK STATUS ===
Website: dragoncomputers.eu | Location: Heerlen, Netherlands

CURRENTLY BUILDABLE (${buildable.length} of ${catalog.length} builds):
${buildableList}

BLOCKED BUILDS (${blocked.length} — missing parts):
${blocked.slice(0,5).map(b=>`- ${b.name}: missing ${b.buildability.outStock.map(c=>c.label).join(", ")}`).join("\n")}

OUT OF STOCK PARTS:
- GPUs: ${blockedGPUs || "none"}
- CPUs: ${blockedCPUs || "none"}

PRICE RANGE: €${Math.min(...catalog.map(b=>b.price)).toLocaleString()} – €${Math.max(...catalog.map(b=>b.price)).toLocaleString()}
`;
  }

  // ── Process email with Claude ─────────────────────────────────────────────

  async function processEmail(email) {
    if (email.result) { setSelected(email); setReplyBody(email.result.reply||""); setDetailTab("reply"); return; }
    setProcessing(true);
    setSelected({...email,_loading:true});
    const ctx = buildAIContext();
    const sys = `You are the AI email assistant for Dragon Computers (dragoncomputers.eu), a gaming PC shop in Heerlen, Netherlands. You have LIVE access to the full Firebreather build catalog and real-time Easybill parts inventory.

${ctx}

Respond ONLY with valid JSON:
{
  "category": one of [ORDER_STATUS,BUDGET_BUILD_REQUEST,STOCK_QUESTION,TECHNICAL_SUPPORT,UPGRADE_REQUEST,GENERAL_INQUIRY],
  "priority": one of [HIGH,MEDIUM,LOW],
  "confidence": 0-1,
  "summary": "one sentence",
  "sentiment": one of [POSITIVE,NEUTRAL,FRUSTRATED,ANGRY],
  "tags": ["tag1","tag2"],
  "recommendedBuilds": [{"name":"build name","price":"€X","reason":"why it matches","buildable":true}],
  "reply": "complete professional reply in English mentioning specific Firebreather model names and real prices",
  "suggestedActions": ["action1","action2"]
}`;
    try {
      const res  = await fetch("/api/anthropic/v1/messages",{method:"POST",headers:{"Content-Type":"application/json","x-api-key":ANTHROPIC_KEY,"anthropic-version":"2023-06-01","anthropic-dangerous-direct-browser-access":"true"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1200,system:sys,messages:[{role:"user",content:`From:${email.from}\nSubject:${email.subject}\n\n${email.body}`}]})});
      const data = await res.json();
      const txt  = data.content?.map(i=>i.text||"").join("")||"";
      const parsed = JSON.parse(txt.replace(/```json|```/g,"").trim());
      const updated = {...email, result:parsed, status:email.status==="UNREAD"?"PENDING":email.status};
      setEmails(prev=>prev.map(e=>e.id===email.id?updated:e));
      setSelected(updated); setReplyBody(parsed.reply||""); setDetailTab("reply");
      showToast("Analyzed with live catalog ✓","success");
    } catch(e) {
      showToast("AI processing failed","error");
      setSelected(email);
    } finally { setProcessing(false); }
  }

  async function sendReply() {
    if(!replyBody.trim()) return;
    setEmails(p=>p.map(e=>e.id===selected.id?{...e,status:"REPLIED"}:e));
    setSelected(p=>({...p,status:"REPLIED"}));
    showToast(`Reply sent to ${selected.from} ✓`,"success");
    setReplyOpen(false);
  }

  // ── Filters ───────────────────────────────────────────────────────────────

  const filteredBuilds = buildsWithStatus.filter(b => {
    const matchStatus = buildFilter==="all" || b.buildability.status===buildFilter;
    const matchCat    = catFilter==="all" || b.category===catFilter;
    const matchSearch = !search || b.name.toLowerCase().includes(search.toLowerCase()) || b.cpu.toLowerCase().includes(search.toLowerCase()) || b.gpu.toLowerCase().includes(search.toLowerCase());
    return matchStatus && matchCat && matchSearch;
  });

  const dragonCats = [...new Set(catalog.map(b=>b.category))];
  const unread     = emails.filter(e=>e.status==="UNREAD").length;
  const catColor   = selected?.result ? (CATEGORIES[selected.result.category]?.color||"#00d4ff") : "#00d4ff";

  // ─── RENDER ───────────────────────────────────────────────────────────────

  return (
    <div style={{minHeight:"100vh",background:"#06060e",fontFamily:"'IBM Plex Mono','Courier New',monospace",color:"#ddd",display:"flex",flexDirection:"column"}}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@300;400;500;600&family=Orbitron:wght@700;900&display=swap');
        *{box-sizing:border-box;margin:0;padding:0}
        ::-webkit-scrollbar{width:3px;height:3px}
        ::-webkit-scrollbar-track{background:#09091a}
        ::-webkit-scrollbar-thumb{background:#1a1a30;border-radius:2px}
        @keyframes blink{0%,100%{opacity:1}50%{opacity:0}}
        @keyframes fadeUp{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:translateY(0)}}
        @keyframes slideIn{from{opacity:0;transform:translateX(16px)}to{opacity:1;transform:translateX(0)}}
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:.15}}
        @keyframes glow{0%,100%{box-shadow:0 0 4px #00ff8844}50%{box-shadow:0 0 12px #00ff8888}}
        .fade{animation:fadeUp .3s ease}
        .btn{cursor:pointer;border:none;font-family:inherit;transition:all .15s}
        .btn:hover{filter:brightness(1.2);transform:translateY(-1px)}
        .btn:active{transform:translateY(0)}
        .ib{cursor:pointer;background:none;border:none;font-family:inherit;padding:4px 7px;border-radius:2px;transition:all .15s}
        .ib:hover{background:rgba(255,255,255,.05)}
        .nav{cursor:pointer;transition:all .15s;border:none;background:none;font-family:inherit}
        .row:hover{background:rgba(255,255,255,.02)!important;cursor:pointer}
        textarea,input{font-family:inherit;outline:none}
        .build-card{transition:all .2s;cursor:default}
        .build-card:hover{border-color:#ffffff18!important;background:#0c0c1c!important}
        .buildable-card{animation:glow 3s infinite}
      `}</style>

      {/* ── HEADER ── */}
      <header style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"10px 20px",borderBottom:"1px solid #10102a",background:"#080815",gap:12,flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <div style={{width:6,height:6,borderRadius:"50%",background:"#00d4ff",boxShadow:"0 0 10px #00d4ff",animation:"pulse 2s infinite",flexShrink:0}}/>
          <span style={{fontFamily:"'Orbitron',monospace",fontSize:12,letterSpacing:3,color:"#00d4ff"}}>DRAGON·AI</span>
          <span style={{color:"#181830",fontSize:9}}>dragoncomputers.eu</span>
        </div>

        {/* Nav */}
        <div style={{display:"flex",background:"#0c0c1e",border:"1px solid #13132a",borderRadius:2,overflow:"hidden"}}>
          {[
            {id:"builds", label:`🏗 Build Status`},
            {id:"inbox",  label:`📧 Inbox${unread>0?` (${unread})`:""}`},
            {id:"parts",  label:"🔩 Parts Stock"},
          ].map((t,i)=>(
            <button key={t.id} className="nav" onClick={()=>setMainTab(t.id)} style={{
              padding:"7px 18px",fontSize:10,letterSpacing:.5,
              background:mainTab===t.id?"rgba(0,212,255,.07)":"transparent",
              color:mainTab===t.id?"#00d4ff":"#333",
              borderRight:i<2?"1px solid #13132a":"none",
            }}>{t.label}</button>
          ))}
        </div>

        <div style={{display:"flex",gap:8,alignItems:"center"}}>
          <div style={{position:"relative"}}>
            <span style={{position:"absolute",left:8,top:"50%",transform:"translateY(-50%)",color:"#222",fontSize:11}}>⌕</span>
            <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search builds, parts…" style={{padding:"6px 8px 6px 24px",background:"#0c0c1e",border:"1px solid #13132a",color:"#666",fontSize:10,borderRadius:2,width:180}}/>
          </div>
          <button className="btn" onClick={syncEasybill} disabled={syncLoading} style={{padding:"6px 14px",background:"#00ff8810",border:"1px solid #00ff8830",color:"#00ff88",fontSize:9,letterSpacing:1,display:"flex",alignItems:"center",gap:6}}>
            <span style={syncLoading?{animation:"spin 1s linear infinite",display:"inline-block"}:{}}>{syncLoading?"⟳":"↻"}</span>
            {syncLoading?"SYNCING…":"SYNC EASYBILL"}
          </button>
          {lastSync && <span style={{fontSize:8,color:"#1e1e35"}}>synced {timeAgo(lastSync)}</span>}
        </div>
      </header>

      {/* ── BUILDS VIEW ── */}
      {mainTab==="builds" && (
        <div className="fade" style={{flex:1,overflow:"auto",padding:20}}>

          {/* Summary bar */}
          <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:10,marginBottom:20}}>
            {[
              {label:"Total Builds",  val:catalog.length,    color:"#00d4ff", sub:"in catalog"},
              {label:"✅ Buildable",  val:buildable.length,  color:"#00ff88", sub:"all parts in stock"},
              {label:"⚠️ Partial",   val:partial.length,    color:"#ffaa00", sub:"some parts missing"},
              {label:"❌ Blocked",   val:blocked.length,    color:"#ff4466", sub:"critical parts out"},
            ].map(s=>(
              <div key={s.label} style={{padding:"14px 16px",background:"#0c0c1e",border:`1px solid ${s.color}22`,borderRadius:2,cursor:"pointer"}} onClick={()=>setBuildFilter(s.label.includes("Buildable")?"BUILDABLE":s.label.includes("Partial")?"PARTIAL":s.label.includes("Blocked")?"BLOCKED":"all")}>
                <div style={{fontSize:26,fontWeight:600,color:s.color,marginBottom:2}}>{s.val}</div>
                <div style={{fontSize:10,color:"#aaa",marginBottom:2}}>{s.label}</div>
                <div style={{fontSize:8,color:"#2a2a40"}}>{s.sub}</div>
              </div>
            ))}
          </div>

          {/* Filters */}
          <div style={{display:"flex",gap:8,marginBottom:16,alignItems:"center",flexWrap:"wrap"}}>
            <div style={{fontSize:9,color:"#2a2a40",letterSpacing:2}}>FILTER:</div>
            {["all","BUILDABLE","PARTIAL","BLOCKED"].map(f=>(
              <button key={f} className="btn" onClick={()=>setBuildFilter(f)} style={{fontSize:9,padding:"4px 10px",background:buildFilter===f?"rgba(0,212,255,.08)":"transparent",border:`1px solid ${buildFilter===f?"#00d4ff44":"#13132a"}`,color:buildFilter===f?"#00d4ff":"#333",letterSpacing:.5}}>
                {f==="all"?"ALL":f==="BUILDABLE"?"✅ BUILDABLE":f==="PARTIAL"?"⚠️ PARTIAL":"❌ BLOCKED"}
              </button>
            ))}
            <div style={{marginLeft:"auto",display:"flex",gap:6}}>
              <select value={catFilter} onChange={e=>setCatFilter(e.target.value)} style={{padding:"4px 10px",background:"#0c0c1e",border:"1px solid #13132a",color:"#555",fontSize:9,cursor:"pointer"}}>
                <option value="all">All Categories</option>
                {dragonCats.map(c=><option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          </div>

          {/* Build cards grid */}
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(320px,1fr))",gap:10}}>
            {filteredBuilds.map(b => {
              const { status, color, icon, components, outStock } = b.buildability;
              return (
                <div key={b.id} className={`build-card${status==="BUILDABLE"?" buildable-card":""}`}
                  style={{background:"#0a0a18",border:`1px solid ${color}22`,borderRadius:3,overflow:"hidden"}}>

                  {/* Card header */}
                  <div style={{padding:"10px 14px",borderBottom:"1px solid #0d0d20",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{fontSize:11,color:"#ddd",fontWeight:500,marginBottom:2,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{b.name}</div>
                      <div style={{fontSize:8,color:"#2a2a40"}}>{b.category}</div>
                    </div>
                    <BuildBadge status={status} color={color} icon={icon}/>
                  </div>

                  {/* Specs */}
                  <div style={{padding:"10px 14px"}}>
                    {components.map((c,i)=>(
                      <div key={i} style={{display:"flex",alignItems:"center",gap:8,marginBottom:6}}>
                        <span style={{fontSize:8,color:"#333",width:48,flexShrink:0}}>{c.type}</span>
                        <span style={{fontSize:9,color:c.notFound?"#555":c.inStock?"#aaa":"#ff4466",flex:1,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{c.label}</span>
                        {c.notFound ? (
                          <span style={{fontSize:7,color:"#555",flexShrink:0}}>not tracked</span>
                        ) : c.inStock ? (
                          <span style={{fontSize:7,padding:"1px 5px",background:"#00ff8815",color:"#00ff88",border:"1px solid #00ff8830",flexShrink:0}}>{c.stock} units</span>
                        ) : (
                          <span style={{fontSize:7,padding:"1px 5px",background:"#ff446615",color:"#ff4466",border:"1px solid #ff446630",flexShrink:0}}>OUT</span>
                        )}
                      </div>
                    ))}

                    {outStock.length > 0 && (
                      <div style={{marginTop:8,padding:"6px 8px",background:"#ff446608",border:"1px solid #ff446620",borderRadius:2,fontSize:9,color:"#ff4466"}}>
                        ❌ Missing: {outStock.map(c=>c.label).join(", ")}
                      </div>
                    )}

                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginTop:10,paddingTop:8,borderTop:"1px solid #0d0d20"}}>
                      <div>
                        <div style={{fontSize:14,color:"#00ff88",fontWeight:600}}>€{b.price.toLocaleString("nl-NL",{minimumFractionDigits:2})}</div>
                        {b.originalPrice>b.price && <div style={{fontSize:8,color:"#333",textDecoration:"line-through"}}>€{b.originalPrice.toLocaleString("nl-NL",{minimumFractionDigits:2})}</div>}
                      </div>
                      <a href={b.url} target="_blank" style={{fontSize:8,padding:"3px 8px",background:"rgba(0,212,255,.07)",border:"1px solid #00d4ff22",color:"#00d4ff",textDecoration:"none",borderRadius:2}}>VIEW ↗</a>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredBuilds.length===0 && (
            <div style={{padding:40,color:"#1a1a30",textAlign:"center",fontSize:12}}>No builds match current filters</div>
          )}
        </div>
      )}

      {/* ── PARTS STOCK VIEW ── */}
      {mainTab==="parts" && (
        <div className="fade" style={{flex:1,overflow:"auto",padding:20}}>
          <div style={{fontSize:9,color:"#2a2a40",letterSpacing:2,marginBottom:16}}>EASYBILL PARTS INVENTORY — {parts.length} ITEMS</div>
          {["CPU","GPU","RAM","Storage"].map(cat=>{
            const catParts = parts.filter(p=>p.category===cat && (!search || p.name.toLowerCase().includes(search.toLowerCase())));
            if (!catParts.length) return null;
            return (
              <div key={cat} style={{marginBottom:24}}>
                <div style={{fontSize:9,color:"#333",letterSpacing:2,marginBottom:8,display:"flex",gap:8,alignItems:"center"}}>
                  {cat.toUpperCase()}
                  <div style={{flex:1,height:1,background:"#0d0d20"}}/>
                  <span style={{color:"#1a1a30"}}>{catParts.filter(p=>p.stock>0).length}/{catParts.length} in stock</span>
                </div>
                <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(240px,1fr))",gap:8}}>
                  {catParts.map(p=>{
                    const s = p.stock===null?{l:"Service",c:"#aa88ff"}:p.stock===0?{l:"OUT",c:"#ff4466"}:p.stock<=2?{l:`LOW (${p.stock})`,c:"#ffaa00"}:{l:`${p.stock} units`,c:"#00ff88"};
                    return (
                      <div key={p.id} style={{padding:"10px 12px",background:"#0a0a18",border:`1px solid ${s.c}22`,borderRadius:2,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                        <div>
                          <div style={{fontSize:11,color:s.c==="OUT"?"#ff4466":"#ccc",marginBottom:2}}>{p.name}</div>
                          <div style={{fontSize:8,color:"#2a2a40"}}>{p.sku}</div>
                        </div>
                        <div style={{textAlign:"right"}}>
                          <span style={{fontSize:8,padding:"2px 6px",background:`${s.c}15`,color:s.c,border:`1px solid ${s.c}30`,display:"block",marginBottom:3}}>{s.l}</span>
                          <span style={{fontSize:10,color:"#444"}}>€{p.price.toFixed(2)}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ── INBOX VIEW ── */}
      {mainTab==="inbox" && (
        <div style={{display:"flex",flex:1,overflow:"hidden",minHeight:0}} className="fade">

          {/* Email list */}
          <div style={{width:320,borderRight:"1px solid #10102a",display:"flex",flexDirection:"column",overflow:"hidden",flexShrink:0}}>
            <div style={{padding:"8px 12px",borderBottom:"1px solid #0d0d1c",fontSize:9,color:"#2a2a40",letterSpacing:2}}>
              {emails.filter(e=>!e.archived).length} EMAILS · {unread} UNREAD
            </div>
            <div style={{overflowY:"auto",flex:1}}>
              {emails.filter(e=>!e.archived).map(email=>{
                const isSel = selected?.id===email.id;
                const cat   = email.result ? CATEGORIES[email.result.category] : null;
                return (
                  <div key={email.id} className="row" onClick={()=>processEmail(email)} style={{
                    padding:"11px 14px",borderBottom:"1px solid #09091a",
                    background:isSel?"rgba(0,212,255,.04)":"transparent",
                    position:"relative",
                  }}>
                    {email.status==="UNREAD"&&<div style={{position:"absolute",left:0,top:"50%",transform:"translateY(-50%)",width:2,height:24,background:"#00d4ff",borderRadius:"0 1px 1px 0"}}/>}
                    <div style={{display:"flex",gap:8}}>
                      <div style={{flex:1,minWidth:0}}>
                        <div style={{display:"flex",justifyContent:"space-between",marginBottom:2}}>
                          <span style={{fontSize:11,color:email.status==="UNREAD"?"#eee":"#555",fontWeight:email.status==="UNREAD"?500:400}}>{email.from.split("@")[0]}</span>
                          <span style={{fontSize:8,color:"#1a1a30"}}>{timeAgo(email.date)}</span>
                        </div>
                        <div style={{fontSize:10,color:email.status==="UNREAD"?"#bbb":"#444",marginBottom:4,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{email.subject}</div>
                        <div style={{display:"flex",gap:4,flexWrap:"wrap"}}>
                          <span style={{fontSize:7,padding:"1px 5px",background:email.status==="UNREAD"?"#00d4ff18":"#ffffff08",color:email.status==="UNREAD"?"#00d4ff":"#333",border:`1px solid ${email.status==="UNREAD"?"#00d4ff30":"#1a1a30"}`}}>{email.status}</span>
                          {cat&&<span style={{fontSize:7,padding:"1px 5px",background:cat.bg,color:cat.color,border:`1px solid ${cat.color}30`}}>{cat.icon} {cat.label}</span>}
                          {email.result?.recommendedBuilds?.filter(b=>b.buildable).length>0 && (
                            <span style={{fontSize:7,padding:"1px 5px",background:"#00ff8815",color:"#00ff88",border:"1px solid #00ff8830"}}>✅ {email.result.recommendedBuilds.filter(b=>b.buildable).length} buildable</span>
                          )}
                        </div>
                      </div>
                      <span onClick={e=>{e.stopPropagation();setEmails(p=>p.map(em=>em.id===email.id?{...em,starred:!em.starred}:em))}} style={{fontSize:11,color:email.starred?"#ffcc00":"#1a1a30",cursor:"pointer",flexShrink:0}}>★</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Detail pane */}
          <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden",minWidth:0}}>
            {!selected ? (
              <div style={{flex:1,display:"flex",alignItems:"center",justifyContent:"center",flexDirection:"column",gap:10,color:"#1a1a30"}}>
                <div style={{fontSize:32}}>🐉</div>
                <div style={{fontSize:11,letterSpacing:2}}>SELECT AN EMAIL</div>
                <div style={{fontSize:9}}>AI will match customer requests to live buildable catalog</div>
              </div>
            ) : (
              <div className="fade" style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
                {/* Header */}
                <div style={{padding:"14px 18px",borderBottom:"1px solid #10102a",flexShrink:0}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:10,marginBottom:8}}>
                    <div style={{flex:1,minWidth:0}}>
                      <h2 style={{fontSize:13,color:"#eee",fontWeight:500,marginBottom:3,fontFamily:"inherit"}}>{selected.subject}</h2>
                      <div style={{fontSize:10,color:"#444"}}>From: <span style={{color:"#777"}}>{selected.from}</span><span style={{color:"#1a1a30",marginLeft:10}}>{timeAgo(selected.date)}</span></div>
                    </div>
                    <div style={{display:"flex",gap:3}}>
                      <button className="ib" onClick={()=>{setReplyOpen(true);setReplyBody(selected.result?.reply||"");}} style={{fontSize:11,color:"#444"}}>↩</button>
                      <button className="ib" onClick={()=>{setEmails(p=>p.map(e=>e.id===selected.id?{...e,archived:true}:e));setSelected(null);showToast("Archived","info");}} style={{fontSize:11,color:"#444"}}>🗃</button>
                      <button className="ib" onClick={()=>{setEmails(p=>p.map(e=>e.id===selected.id?{...e,status:"REPLIED"}:e));setSelected(p=>({...p,status:"REPLIED"}));showToast("Marked replied","success");}} style={{fontSize:11,color:"#444"}}>✓</button>
                    </div>
                  </div>
                  {selected.result&&(
                    <div style={{display:"flex",gap:5,flexWrap:"wrap",alignItems:"center"}}>
                      <span style={{fontSize:8,padding:"2px 6px",background:CATEGORIES[selected.result.category]?.bg,color:CATEGORIES[selected.result.category]?.color,border:`1px solid ${CATEGORIES[selected.result.category]?.color}30`}}>
                        {CATEGORIES[selected.result.category]?.icon} {CATEGORIES[selected.result.category]?.label}
                      </span>
                      <span style={{fontSize:8,padding:"2px 6px",background:"#ffffff07",color:selected.result.priority==="HIGH"?"#ff4466":selected.result.priority==="MEDIUM"?"#ffaa00":"#444",border:"1px solid #1a1a30"}}>{selected.result.priority}</span>
                      {{POSITIVE:"😊",NEUTRAL:"😐",FRUSTRATED:"😤",ANGRY:"😡"}[selected.result.sentiment]&&<span style={{fontSize:11}}>{{POSITIVE:"😊",NEUTRAL:"😐",FRUSTRATED:"😤",ANGRY:"😡"}[selected.result.sentiment]}</span>}
                    </div>
                  )}
                </div>

                {/* Tabs */}
                <div style={{display:"flex",borderBottom:"1px solid #10102a",flexShrink:0,padding:"0 18px"}}>
                  {[{id:"reply",label:"AI Reply"},{id:"builds",label:`Buildable Matches${selected.result?.recommendedBuilds?.length>0?` (${selected.result.recommendedBuilds.length})`:""}`},{id:"raw",label:"Original"}].map(t=>(
                    <button key={t.id} className="nav" onClick={()=>setDetailTab(t.id)} style={{padding:"8px 14px",fontSize:9,letterSpacing:.5,color:detailTab===t.id?catColor:"#2a2a3a",borderBottom:detailTab===t.id?`2px solid ${catColor}`:"2px solid transparent",marginBottom:-1}}>{t.label}</button>
                  ))}
                </div>

                {/* Tab content */}
                <div style={{flex:1,overflow:"auto",padding:18}}>
                  {(selected._loading||processing)&&(
                    <div style={{display:"flex",gap:10,alignItems:"center",color:"#00d4ff",padding:"24px 0"}}>
                      <span style={{animation:"spin 1s linear infinite",display:"inline-block",fontSize:16}}>⟳</span>
                      <div>
                        <div style={{fontSize:11}}>Analyzing against live Dragon catalog…</div>
                        <div style={{fontSize:9,color:"#2a2a40",marginTop:2}}>Matching stock · Finding buildable options · Drafting reply</div>
                      </div>
                    </div>
                  )}

                  {!selected._loading&&!processing&&selected.result&&(
                    <>
                      {detailTab==="reply"&&(
                        <div className="fade">
                          <div style={{fontSize:8,color:"#2a2a40",letterSpacing:2,marginBottom:8}}>AI SUMMARY</div>
                          <div style={{padding:"8px 12px",background:"#0c0c1e",borderLeft:`2px solid ${catColor}`,marginBottom:16,fontSize:11,color:"#666",lineHeight:1.7}}>
                            <TW text={selected.result.summary} speed={18}/>
                          </div>
                          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
                            <div style={{fontSize:8,color:"#2a2a40",letterSpacing:2}}>DRAFT REPLY <span style={{color:"#00ff8833"}}>— references live stock</span></div>
                            <div style={{display:"flex",gap:6}}>
                              <button className="btn" onClick={()=>navigator.clipboard?.writeText(replyBody||selected.result.reply).then(()=>showToast("Copied!","success"))} style={{fontSize:8,padding:"3px 8px",background:"#0c0c1e",border:"1px solid #13132a",color:"#444"}}>COPY</button>
                              <button className="btn" onClick={()=>{setReplyOpen(true);setReplyBody(selected.result.reply);}} style={{fontSize:8,padding:"3px 8px",background:`${catColor}12`,border:`1px solid ${catColor}30`,color:catColor}}>EDIT & SEND</button>
                            </div>
                          </div>
                          {!replyOpen?(
                            <div style={{padding:14,background:"#090f0b",border:"1px solid #00ff8815",borderRadius:2,fontSize:11,color:"#777",lineHeight:1.9,whiteSpace:"pre-wrap"}}>
                              <TW text={selected.result.reply} speed={3}/>
                            </div>
                          ):(
                            <div>
                              <textarea value={replyBody} onChange={e=>setReplyBody(e.target.value)} rows={9} style={{width:"100%",padding:12,background:"#090f0b",border:"1px solid #00ff8825",color:"#bbb",fontSize:11,lineHeight:1.8,resize:"vertical",borderRadius:2}}/>
                              <div style={{display:"flex",gap:8,marginTop:8}}>
                                <button className="btn" onClick={sendReply} style={{padding:"8px 18px",background:"#00ff8812",border:"1px solid #00ff8835",color:"#00ff88",fontSize:10,letterSpacing:1}}>↩ SEND REPLY</button>
                                <button className="btn" onClick={()=>setReplyOpen(false)} style={{padding:"8px 14px",background:"transparent",border:"1px solid #13132a",color:"#333",fontSize:10}}>CANCEL</button>
                              </div>
                            </div>
                          )}
                        </div>
                      )}

                      {detailTab==="builds"&&(
                        <div className="fade">
                          <div style={{fontSize:8,color:"#2a2a40",letterSpacing:2,marginBottom:14}}>RECOMMENDED BUILDS — CROSS-CHECKED WITH LIVE STOCK</div>
                          {(!selected.result.recommendedBuilds||selected.result.recommendedBuilds.length===0)?(
                            <div style={{color:"#2a2a40",fontSize:11}}>No specific builds recommended for this email.</div>
                          ):selected.result.recommendedBuilds.map((rec,i)=>{
                            const realBuild = buildsWithStatus.find(b=>b.name.toLowerCase().includes(rec.name?.toLowerCase()?.split(" ").slice(0,3).join(" ")||""));
                            const ba = realBuild?.buildability;
                            return (
                              <div key={i} style={{padding:14,background:"#0a0a18",border:`1px solid ${ba?ba.color+"33":"#13132a"}`,borderRadius:2,marginBottom:10}}>
                                <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:8}}>
                                  <div style={{flex:1,minWidth:0}}>
                                    <div style={{fontSize:12,color:"#ddd",fontWeight:500,marginBottom:3}}>{rec.name}</div>
                                    <div style={{fontSize:10,color:"#555",fontStyle:"italic"}}>{rec.reason}</div>
                                  </div>
                                  <div style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:4,flexShrink:0,marginLeft:12}}>
                                    <span style={{fontSize:13,color:"#00ff88",fontWeight:600}}>{rec.price}</span>
                                    {ba&&<BuildBadge status={ba.status} color={ba.color} icon={ba.icon} small/>}
                                  </div>
                                </div>
                                {realBuild&&(
                                  <div style={{marginTop:8}}>
                                    <div style={{fontSize:8,color:"#2a2a40",marginBottom:6}}>COMPONENT STOCK CHECK:</div>
                                    {ba.components.map((c,ci)=>(
                                      <div key={ci} style={{display:"flex",alignItems:"center",gap:8,marginBottom:4}}>
                                        <span style={{fontSize:8,color:"#2a2a35",width:44,flexShrink:0}}>{c.type}</span>
                                        <span style={{fontSize:9,color:"#666",flex:1,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{c.label}</span>
                                        {c.notFound?<span style={{fontSize:7,color:"#555"}}>—</span>:c.inStock?(
                                          <span style={{fontSize:7,padding:"1px 5px",background:"#00ff8815",color:"#00ff88",border:"1px solid #00ff8830",flexShrink:0}}>{c.stock} in stock</span>
                                        ):(
                                          <span style={{fontSize:7,padding:"1px 5px",background:"#ff446615",color:"#ff4466",border:"1px solid #ff446630",flexShrink:0}}>OUT OF STOCK</span>
                                        )}
                                      </div>
                                    ))}
                                  </div>
                                )}
                                {realBuild&&<a href={realBuild.url} target="_blank" style={{display:"inline-block",marginTop:10,fontSize:8,padding:"3px 10px",background:"rgba(0,212,255,.07)",border:"1px solid #00d4ff22",color:"#00d4ff",textDecoration:"none"}}>VIEW ON DRAGONCOMPUTERS.EU ↗</a>}
                              </div>
                            );
                          })}
                        </div>
                      )}

                      {detailTab==="raw"&&(
                        <div className="fade">
                          <div style={{fontSize:8,color:"#2a2a40",letterSpacing:2,marginBottom:10}}>ORIGINAL MESSAGE</div>
                          <div style={{padding:14,background:"#0a0a18",border:"1px solid #13132a",borderRadius:2,fontSize:11,color:"#555",lineHeight:1.9,whiteSpace:"pre-wrap"}}>{selected.body}</div>
                        </div>
                      )}
                    </>
                  )}

                  {!selected._loading&&!processing&&!selected.result&&(
                    <div style={{color:"#1a1a30",fontSize:11,padding:"16px 0"}}>Click email to analyze against Dragon catalog…</div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setToast(null)}/>}
    </div>
  );
}
