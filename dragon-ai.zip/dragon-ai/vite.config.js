import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api/anthropic': {
        target: 'https://api.anthropic.com',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api\/anthropic/, ''),
        headers: {
          'anthropic-dangerous-direct-browser-access': 'true'
        }
      },
      '/api/easybill': {
        target: 'https://api.easybill.de',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api\/easybill/, '')
      },
      '/api/graph': {
        target: 'https://graph.microsoft.com',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api\/graph/, '')
      }
    }
  }
})
